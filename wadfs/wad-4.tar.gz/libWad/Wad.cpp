#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <cstdlib>
#include <cstring>
#include <unistd.h>
#include <fcntl.h>
#include "WadNode.h"
#include "Wad.h"
using namespace std;

string path;
int file;
int descriptorNo;
vector<WadNode*> nodes;
string magic;
int offset;

int readInt() {
        char buf2[4];
        read(file, &buf2, 4);
        int temp = (int)buf2[0] | (int)buf2[1]<<8 | (int)buf2[2]<<16 | (int)buf2[3]<<24;
        return temp;
}

int initializeDir(int index, string path, int count) {
	//cout << index << " " << path << " " << count << endl;
	//printf("%d %s %d\n", index, path.c_str(), count);
	string name = nodes[index]-> name;
	bool a = 0;
	bool b = 0;
	string c = name.substr(1,1);
	string d = name.substr(3,1);
	vector<string> nums{"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"};
	for (int i = 0; i < nums.size(); i++) {
		if (c == nums[i]) {
			a = 1;
		}
		if (d == nums[i]) {
			b = 1;
		}
	}

	if (name.substr(0,1) == "E" && name.substr(2,1) == "M" && a && b) {
		//do stuff for E#M# case
		for (int i = 0; i < 10; i++) {
			 int offset;
                	read(file, &offset, 4);
                	int length;
                	read(file, &length, 4);
                	char temp[8];
                	read(file, &temp, 8);
                	string name(temp);
                	WadNode* test = new WadNode(offset, length, name, path);
                	nodes.push_back(test);
			count++;
			nodes[index]->children.push_back(test);
			if (test->_isContent == 0) {
				int index2 = nodes.size() - 1;
				count = initializeDir(index2, test->path, count);
			}
		}
	}
	else if (name.length() >= 6 && name.substr(name.length() - 6, 6) == "_START") {
		nodes[index]->name = name.substr(0, name.length() - 6);
                nodes[index]->path = path.substr(0, path.length() - 6);
		path = nodes[index]->path;
		bool b = 1;
		while(b) {
			//Second case: namespace
			int offset;
			read(file, &offset, 4);
			int length;
			read(file, &length, 4);
			char temp[8];
			read(file, &temp, 8);
			string name(temp);
			if (name.length() >= 4 && name.substr(name.length() - 4, 4) == "_END") {
				b = 0;
				count++;
			}
			else {
				WadNode* test = new WadNode(offset, length, name, path);
                        	nodes.push_back(test);
				count++;
                        	nodes[index]->children.push_back(test);
                        	if (test->_isContent == 0) {
                                	int index2 = nodes.size() - 1;
                                	count = initializeDir(index2, test->path, count);
                        	}
			}
		}
	}
	return count;
}

void storeData(WadNode* root) {
        for (int i = 0; i < root->children.size(); i++) {
                if (root->children[i]->_isContent) {
                        string path = root->children[i]->path;
                        int size = root->children[i]->length;
			lseek(file, root->children[i]->offset, SEEK_SET);
			root->children[i]->content = new char[size];
			read(file, root->children[i]->content, size);
			//char content[size];
			//read(file, content, size);
			//root->children[i]->content = string(content);
			//getContents(root->children[i]->path, root->children[i]->content, size);
                }
		else {
			storeData(root->children[i]);
		}
        }
}

void readDescriptors() {
	lseek(file, offset, SEEK_SET);
	int count = 0;
	while (count < descriptorNo) {
        	int offset;
        	read(file, &offset, 4);
		int length;
		read(file, &length, 4);
		char temp[8];
		read(file, &temp, 8);
		string name(temp);
		WadNode* test = new WadNode(offset, length, name, "");
		nodes.push_back(test);
		nodes[0]->children.push_back(test);
		count++;
		if (test->_isContent == 0) {
			int index = nodes.size() - 1;
			count = initializeDir(index, test->path, count);
			//cout << "Finished!" << endl;
		}
		//cout << "Stuck here!!!" << endl;
	}
}

WadNode* findNode(const string &path2) {
	if (path2 == "/") {
		return nodes[0];
	}
	string path = path2;
	path.append("/");
	int start = -2;
	int end = -1;
	vector<string> pathVec;
	const char* temp = path.c_str();
	for(int i = 0; i < path.length(); i++) {
		if (start < end && temp[i] == '/') {
			start = i;
		}
		else if (start >= end && temp[i] == '/') {
			end = i;
			pathVec.push_back(path.substr(start + 1, end - start - 1));
			start = i;
		}
	}

	WadNode* found = nodes[0];
	for (int i = 0; i < pathVec.size(); i++) {
		bool validPath = 0;
		for (int j = 0; j < found->children.size(); j++) {
			if (found->children[j]->name == pathVec[i]) {
				found = found->children[j];
				validPath = 1;
				break;
			}
		}
		if (!validPath) {
			found = nullptr;
			break;
		}
	}
	return found;
}

Wad* Wad::loadWad(const string &path) {
	file = open(path.c_str(), O_RDONLY);

	if (file == -1) {
		return nullptr;
	}

	Wad* newWad = new Wad();

	//Get magic
	char buf[4];
	read(file, buf, 4);
	string temp(buf);
	magic = temp;

	//Get number of descriptors
	read(file, &descriptorNo, 4);
	//descriptorNo = readInt();

	//Get descirptor offset
	read(file, &offset, 4);

	//Ok so: go to the offset and start reading descriptors
	/*lseek(file, offset, SEEK_SET);
	int check;
	read(file, &check, 4);*/
	WadNode* root = new WadNode(-1, 0, "", "");
	nodes.push_back(root);
	readDescriptors();
	nodes[0]->length = nodes[0]->children.size();
	storeData(nodes[0]);

	//testing
	/*for (int i = 0; i < nodes.size(); i++) {
		cout << nodes[i]->offset << " " << nodes[i]->length << " " << nodes[i]->path << endl;
	}*/
	return newWad;
}

string Wad::getMagic() {
	return magic;
}

bool Wad::isContent(const string &path) {
	WadNode* temp = findNode(path);
	if (temp != nullptr) {
		return temp->_isContent;
	}
	return 0;
}

bool Wad::isDirectory(const string &path) {
	WadNode* temp = findNode(path);
	if (temp != nullptr) {
		bool isDir = !(temp->_isContent);
		return isDir;
	}
	return 0;
}

int Wad::getSize(const string &path) {
	WadNode* temp = findNode(path);
	if (temp != nullptr) {
		int size = temp->length;
		return size;
	}
	return -1;
}

int Wad::getContents(const string &path, char* buffer, int length, int offset) {
	WadNode* temp = findNode(path);
	if (temp != nullptr && temp->_isContent) {
		//lseek(file, temp->offset + offset, SEEK_SET);
		const char* c = temp->content;
		int sz = temp->length;
		if (offset >= sz) {
			return 0;
		}
		if (offset + length > sz) {
			memcpy(buffer, c + offset, sz - offset);
			return sz - offset;
		}
		memcpy(buffer, c + offset, length);
		return length;
	}
	else {
		return -1;
	}
	return 0;
}

int Wad::getDirectory(const string &path, vector<string> *directory) {
	//cout << path << endl;
	const char* path2 = path.c_str();
	string path3;
	if (path2[path.length() - 1] == '/') {
		path3 = path.substr(0, path.length() - 1);
	}
	else {
		path3 = path;
	}
	const string path4 = path3;

	WadNode* temp = findNode(path4);
	if (temp != nullptr && !(temp->_isContent)) {
		for(int i = 0; i < temp->children.size(); i++) {
			directory->push_back(temp->children[i]->name);
		}
		return directory->size();
	}
	else {
		return -1;
	}
}

WadNode* Wad::getRoot() {
	return nodes[0];
}

Wad::~Wad() {
	//cout << nodes.size() << endl;
	for (int i = 0; i < nodes.size(); i++) {
		delete nodes[i];
	}
}
