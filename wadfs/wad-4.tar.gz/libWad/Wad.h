#pragma once
#include <iostream>
#include <fstream>
#include <vector>
#include "WadNode.h"
using namespace std;

class Wad {
	/*private:
	extern int file;
	extern vector<WadNode*> nodes;
	extern string magic;*/

	public:
	static Wad* loadWad(const string &path);
	string getMagic();
	bool isContent(const string &path);
	bool isDirectory(const string &path);
	int getSize(const string &path);
	int getContents(const string &path, char *buffer, int length, int offset = 0);
	int getDirectory(const string &path, vector<string> *directory);
	WadNode* getRoot();
	~Wad();
};
