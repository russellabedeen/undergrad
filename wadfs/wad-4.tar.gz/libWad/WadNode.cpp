#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include "WadNode.h"

WadNode::WadNode(int _offset, int _length, string _name, string inputPath) {
	offset = _offset;
	length = _length;
	name = _name;
	path = inputPath + "/" + name;
	if (length == 0) {
		_isContent = 0;
	}
	else {
		_isContent = 1;
	}
}

WadNode::~WadNode() {
	/*for (int i = 0; i < children.size(); i++) {
		delete children[i];
	}*/
	if (length != 0) {
		delete[] content;
	}
}
