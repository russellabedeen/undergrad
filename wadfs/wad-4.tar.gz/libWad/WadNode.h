#pragma once
#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

class WadNode {
	public:
	string name;
	bool _isContent;
	int length;
	char* content;
	string path;
	int offset;
	WadNode* parent;
	vector<WadNode*> children;
	WadNode(int _offset, int _length, string _name, string inputPath);
	~WadNode();
};
